main() {
   int a,b,c,d;

   a = 10@;
   a = b + c;

}
